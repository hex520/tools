# Weblogic 12.2.1.3 基础镜像

请登录[https://container-registry.oracle.com/pls/apex/f?p=113:4:15548906741410::NO:::](https://container-registry.oracle.com/pls/apex/f?p=113:4:15548906741410::NO:::)，并同意条款，方可下载并使用这个镜像。

该镜像为官方提供试用版，请勿使用在正式环境，由此产生的任何纠纷，与本项目（vulhub）无关。
