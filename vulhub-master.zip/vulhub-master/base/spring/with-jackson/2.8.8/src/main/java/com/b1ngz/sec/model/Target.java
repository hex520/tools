package com.b1ngz.sec.model;

/**
 * Created by b1ngz on 2018/9/8.
 */
public class Target {
    private Object param;

    public Object getParam() {
        return param;
    }

    public void setParam(Object param) {
        this.param = param;
    }
}
