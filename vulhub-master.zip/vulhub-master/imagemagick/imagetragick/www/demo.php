<?php
echo shell_exec("/usr/local/bin/identify vul.jpg");